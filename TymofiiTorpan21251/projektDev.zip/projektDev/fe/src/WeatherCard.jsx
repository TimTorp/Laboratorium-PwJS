function WeatherCard({ data }) {
    const today = data?.days?.[0];
    if (!today) return <p>Brak danych pogodowych.</p>;

    return (
        <div className="card">
            <h2>{data.resolvedAddress}</h2>
            <p><strong>Data:</strong> {today.datetime}</p>
            <p><strong>Temperatura:</strong> {today.temp} °C</p>
            <p><strong>Warunki:</strong> {today.conditions}</p>
        </div>
    );
}

export default WeatherCard;

import { useState } from 'react';
import WeatherCard from './WeatherCard';
import React from 'react';


function App() {
    console.log("App działa");
    const [city, setCity] = useState('');
    const [weather, setWeather] = useState(null);
    const [error, setError] = useState(null);

    const fetchWeather = async () => {
        if (!city) return;
        try {
            const res = await fetch(`http://localhost:5000/weather?city=${encodeURIComponent(city)}`);
            const data = await res.json();
            setWeather(data);
            setError(null);
        } catch (err) {
            console.error(err);
            setWeather(null);
            setError('Nie udało się pobrać danych.');
        }
    };

    return (
        <div className="container">
            <h1>Pogoda</h1>
            <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Wpisz miasto..."
            />
            <button onClick={fetchWeather}>Szukaj</button>

            {error && <p className="error">{error}</p>}
            {weather && <WeatherCard data={weather} />}
        </div>
    );
}

export default App;
